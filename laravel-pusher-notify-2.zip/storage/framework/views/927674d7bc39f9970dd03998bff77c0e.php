<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Demo Application</title>

</head>

<body>



    <script src="//js.pusher.com/3.1/pusher.min.js"></script>


    <script>
        // Enable pusher logging - don't include this in production
        // Pusher.logToConsole = true;

        var pusher = new Pusher('52fd3d9407abb53a9fac', {
            encrypted: true
        });

        // Subscribe to the channel we specified in our Laravel Event
        var channel = pusher.subscribe('status-liked');

        // Bind a function to a Event (the full Laravel class)
        channel.bind('App\\Events\\StatusLiked', function(data) {
            console.log('hello World', data);
        });
    </script>
</body>

</html>
<?php /**PATH D:\xampp82\htdocs\laravel-pusher-notify\resources\views/welcome.blade.php ENDPATH**/ ?>