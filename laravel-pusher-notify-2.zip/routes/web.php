<?php

use App\Events\FirstNotifyEvent;
use App\Events\NewUserRegisterEvent;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/test',function() {
    event(new App\Events\StatusLiked('Rohit'));
    // NewUserRegisterEvent::dispatch('Hello World');
    // event(new App\Events\NewUserRegisterEvent('hello world'));

    return 'Done';
});

